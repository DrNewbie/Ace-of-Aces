SentryGunBase.AMMO_MUL = {
	1,
	1.5,
	2.5
}