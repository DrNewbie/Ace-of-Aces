tweak_data.interaction.hack_keycard = {
	text_id = "hud_int_hack_keycard",
	start_active = false,
	timer = 100,
	no_contour = true,
	action_text_id = "hud_action_hack_keycard",
	interaction_obj = Idstring("Spine2")
}